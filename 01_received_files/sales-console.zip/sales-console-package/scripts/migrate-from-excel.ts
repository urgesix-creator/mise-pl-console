/**
 * 既存Excelデータ移行スクリプト
 *
 * 使い方:
 *   npm install xlsx @supabase/supabase-js
 *   npx tsx scripts/migrate-from-excel.ts <excel-file-path> [--dry-run]
 *
 * 例:
 *   npx tsx scripts/migrate-from-excel.ts ./data/aoki-thai-2026-01.xlsx
 *   npx tsx scripts/migrate-from-excel.ts ./data/aoki-thai-2026-01.xlsx --dry-run
 *
 * 前提:
 * - SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY を環境変数に設定
 * - 既存Excelの形式を本ファイルの parseExcelToRecords() でパース可能なように調整
 *
 * 注意:
 * - --dry-run でまずDBに書き込まず内容を確認
 * - UPSERT 方式（要件定義 v2.3 準拠）：既存レコードは上書き
 * - 移行前にバックアップ推奨
 */

import * as XLSX from 'xlsx';
import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';

// ====================================================================
// 設定
// ====================================================================

const SUPABASE_URL = process.env.SUPABASE_URL || '';
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error('Error: SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

// ====================================================================
// 型定義
// ====================================================================

type DailySaleRecord = {
  store_id: string;
  business_date: string;
  day_period: 'all' | 'lunch' | 'dinner';
  gross_sales: number;
  net_sales: number;
  service_fee: number;
  tax_amount: number;
  customer_count: number;
  weather?: string | null;
  event_note?: string | null;
};

type DailyPurchaseRecord = {
  store_id: string;
  supplier_id: string;
  business_date: string;
  amount: number;
};

type DailyExpenseRecord = {
  store_id: string;
  expense_account_id: string;
  business_date: string;
  amount: number;
};

type ParsedExcel = {
  storeName: string;
  countryId: string;
  sales: DailySaleRecord[];
  purchases: DailyPurchaseRecord[];
  expenses: DailyExpenseRecord[];
  warnings: string[];
};

// ====================================================================
// Excel パース処理（既存Excelの形式に応じて調整）
// ====================================================================

/**
 * Excel ファイルをパースして移行用レコードに変換
 *
 * 既存Excelの想定構造:
 * - シート1「売上」: A列=日付, B列=昼夜, C列=税込売上, D列=客数, E列=天気, F列=備考
 * - シート2「仕入」: A列=日付, B列=仕入先名, C列=金額
 * - シート3「販管費」: A列=日付, B列=科目名, C列=金額
 *
 * ※ 実際の形式に合わせて修正すること
 */
async function parseExcelToRecords(filePath: string): Promise<ParsedExcel> {
  const warnings: string[] = [];
  const buffer = fs.readFileSync(filePath);
  const workbook = XLSX.read(buffer, { type: 'buffer' });

  // 1. ファイル名から店舗を推定（要調整）
  const fileName = filePath.split('/').pop() || '';
  const storeName = inferStoreNameFromFileName(fileName);
  
  // 2. 店舗マスタから store_id を取得
  const { data: stores, error: storeErr } = await supabase
    .from('stores')
    .select('id, name, country_id, currency_id, service_fee_rate')
    .eq('name', storeName)
    .single();
  
  if (storeErr || !stores) {
    throw new Error(`店舗が見つかりません: ${storeName}`);
  }
  const store = stores;
  
  // 3. 国マスタから tax_rate を取得
  const { data: country } = await supabase
    .from('countries')
    .select('tax_rate, tax_base')
    .eq('id', store.country_id)
    .single();
  
  if (!country) throw new Error(`国マスタが見つかりません: ${store.country_id}`);

  // 4. 仕入先マスタを取得（名前→ID変換用）
  const { data: suppliers } = await supabase
    .from('suppliers')
    .select('id, name')
    .eq('store_id', store.id);
  const supplierMap = new Map((suppliers || []).map(s => [s.name, s.id]));

  // 5. 販管費科目マスタを取得
  const { data: accounts } = await supabase
    .from('expense_accounts')
    .select('id, name')
    .eq('store_id', store.id);
  const accountMap = new Map((accounts || []).map(a => [a.name, a.id]));

  // ====================================================================
  // シート1: 売上
  // ====================================================================
  const sales: DailySaleRecord[] = [];
  const salesSheet = workbook.Sheets['売上'];
  if (salesSheet) {
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(salesSheet);
    for (const row of rows) {
      const date = parseDate(row['日付']);
      if (!date) {
        warnings.push(`売上シート: 日付が無効な行をスキップ: ${JSON.stringify(row)}`);
        continue;
      }
      
      const dayPeriod = parseDayPeriod(row['昼夜']);
      const grossSales = Number(row['税込売上']) || 0;
      const customerCount = Number(row['客数']) || 0;
      
      // 税計算
      const { netSales, serviceFee, taxAmount } = calculateTaxBreakdown(
        grossSales,
        store.service_fee_rate,
        country.tax_rate,
        country.tax_base
      );
      
      sales.push({
        store_id: store.id,
        business_date: date,
        day_period: dayPeriod,
        gross_sales: grossSales,
        net_sales: netSales,
        service_fee: serviceFee,
        tax_amount: taxAmount,
        customer_count: customerCount,
        weather: row['天気'] as string || null,
        event_note: row['備考'] as string || null,
      });
    }
  }

  // ====================================================================
  // シート2: 仕入
  // ====================================================================
  const purchases: DailyPurchaseRecord[] = [];
  const purchaseSheet = workbook.Sheets['仕入'];
  if (purchaseSheet) {
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(purchaseSheet);
    for (const row of rows) {
      const date = parseDate(row['日付']);
      const supplierName = row['仕入先名'] as string;
      const amount = Number(row['金額']) || 0;
      
      if (!date || !supplierName || amount <= 0) {
        warnings.push(`仕入シート: 不完全な行をスキップ: ${JSON.stringify(row)}`);
        continue;
      }
      
      const supplierId = supplierMap.get(supplierName);
      if (!supplierId) {
        warnings.push(`仕入シート: 未登録の仕入先「${supplierName}」(${date})`);
        continue;
      }
      
      purchases.push({
        store_id: store.id,
        supplier_id: supplierId,
        business_date: date,
        amount,
      });
    }
  }

  // ====================================================================
  // シート3: 販管費
  // ====================================================================
  const expenses: DailyExpenseRecord[] = [];
  const expenseSheet = workbook.Sheets['販管費'];
  if (expenseSheet) {
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(expenseSheet);
    for (const row of rows) {
      const date = parseDate(row['日付']);
      const accountName = row['科目名'] as string;
      const amount = Number(row['金額']) || 0;
      
      if (!date || !accountName || amount <= 0) {
        warnings.push(`販管費シート: 不完全な行をスキップ: ${JSON.stringify(row)}`);
        continue;
      }
      
      const accountId = accountMap.get(accountName);
      if (!accountId) {
        warnings.push(`販管費シート: 未登録の科目「${accountName}」(${date})`);
        continue;
      }
      
      expenses.push({
        store_id: store.id,
        expense_account_id: accountId,
        business_date: date,
        amount,
      });
    }
  }

  return {
    storeName: store.name,
    countryId: store.country_id,
    sales,
    purchases,
    expenses,
    warnings,
  };
}

// ====================================================================
// ユーティリティ
// ====================================================================

function inferStoreNameFromFileName(fileName: string): string {
  // 例: "aoki-thai-2026-01.xlsx" → "あお季タイ"
  // ファイル名規則に応じて調整
  if (fileName.includes('aoki-thai')) return 'あお季タイ';
  if (fileName.includes('aoki-robata')) return 'AOKI ロバタ';
  if (fileName.includes('hakata-jakarta')) return '博多天神ジャカルタ';
  throw new Error(`ファイル名から店舗を推定できません: ${fileName}`);
}

function parseDate(value: unknown): string | null {
  if (!value) return null;
  
  // Excel のシリアル値の場合
  if (typeof value === 'number') {
    const d = XLSX.SSF.parse_date_code(value);
    if (d) return `${d.y}-${String(d.m).padStart(2, '0')}-${String(d.d).padStart(2, '0')}`;
  }
  
  // 文字列の場合
  if (typeof value === 'string') {
    const d = new Date(value);
    if (!isNaN(d.getTime())) {
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    }
  }
  
  return null;
}

function parseDayPeriod(value: unknown): 'all' | 'lunch' | 'dinner' {
  const s = String(value || '').toLowerCase().trim();
  if (s.includes('lunch') || s.includes('昼') || s === '昼') return 'lunch';
  if (s.includes('dinner') || s.includes('夜') || s === '夜') return 'dinner';
  return 'all';
}

function calculateTaxBreakdown(
  grossSales: number,
  serviceFeeRate: number,
  taxRate: number,
  taxBase: 'net_sales' | 'net_plus_service'
): { netSales: number; serviceFee: number; taxAmount: number } {
  let netSales: number;
  let serviceFee: number;
  let taxAmount: number;
  
  if (taxBase === 'net_sales') {
    netSales = grossSales / (1 + serviceFeeRate + taxRate);
    serviceFee = netSales * serviceFeeRate;
    taxAmount = netSales * taxRate;
  } else {
    netSales = grossSales / ((1 + serviceFeeRate) * (1 + taxRate));
    serviceFee = netSales * serviceFeeRate;
    taxAmount = (netSales + serviceFee) * taxRate;
  }
  
  return {
    netSales: Math.round(netSales * 100) / 100,
    serviceFee: Math.round(serviceFee * 100) / 100,
    taxAmount: Math.round(taxAmount * 100) / 100,
  };
}

// ====================================================================
// DB 書き込み（UPSERT）
// ====================================================================

async function upsertSales(records: DailySaleRecord[], dryRun: boolean): Promise<void> {
  if (dryRun) {
    console.log(`[DRY-RUN] 売上 ${records.length} 件をUPSERT予定`);
    return;
  }
  
  const { error } = await supabase
    .from('daily_sales')
    .upsert(records, { onConflict: 'store_id,business_date,day_period' });
  
  if (error) throw new Error(`売上UPSERT失敗: ${error.message}`);
  console.log(`✅ 売上 ${records.length} 件をUPSERT`);
}

async function upsertPurchases(records: DailyPurchaseRecord[], dryRun: boolean): Promise<void> {
  if (dryRun) {
    console.log(`[DRY-RUN] 仕入 ${records.length} 件をUPSERT予定`);
    return;
  }
  
  const { error } = await supabase
    .from('daily_purchases')
    .upsert(records, { onConflict: 'store_id,business_date,supplier_id' });
  
  if (error) throw new Error(`仕入UPSERT失敗: ${error.message}`);
  console.log(`✅ 仕入 ${records.length} 件をUPSERT`);
}

async function upsertExpenses(records: DailyExpenseRecord[], dryRun: boolean): Promise<void> {
  if (dryRun) {
    console.log(`[DRY-RUN] 販管費 ${records.length} 件をUPSERT予定`);
    return;
  }
  
  const { error } = await supabase
    .from('daily_expenses')
    .upsert(records, { onConflict: 'store_id,business_date,expense_account_id' });
  
  if (error) throw new Error(`販管費UPSERT失敗: ${error.message}`);
  console.log(`✅ 販管費 ${records.length} 件をUPSERT`);
}

// ====================================================================
// メイン
// ====================================================================

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const filePath = args[0];
  const dryRun = args.includes('--dry-run');

  if (!filePath) {
    console.error('使い方: npx tsx migrate-from-excel.ts <file.xlsx> [--dry-run]');
    process.exit(1);
  }
  
  console.log(`📂 ファイル: ${filePath}`);
  console.log(`🔧 モード: ${dryRun ? 'DRY-RUN（DB書き込みなし）' : '本番投入'}`);
  console.log('');
  
  try {
    // 1. Excelをパース
    console.log('📋 Excelをパース中...');
    const parsed = await parseExcelToRecords(filePath);
    
    console.log(`✅ パース完了: ${parsed.storeName} (${parsed.countryId})`);
    console.log(`   - 売上: ${parsed.sales.length} 件`);
    console.log(`   - 仕入: ${parsed.purchases.length} 件`);
    console.log(`   - 販管費: ${parsed.expenses.length} 件`);
    console.log('');
    
    // 2. 警告の表示
    if (parsed.warnings.length > 0) {
      console.log(`⚠️  警告 (${parsed.warnings.length} 件):`);
      parsed.warnings.slice(0, 10).forEach(w => console.log(`   ${w}`));
      if (parsed.warnings.length > 10) {
        console.log(`   ... 他 ${parsed.warnings.length - 10} 件`);
      }
      console.log('');
    }
    
    // 3. DB UPSERT
    console.log('💾 DB へ書き込み中...');
    await upsertSales(parsed.sales, dryRun);
    await upsertPurchases(parsed.purchases, dryRun);
    await upsertExpenses(parsed.expenses, dryRun);
    
    console.log('');
    console.log(`🎉 ${dryRun ? '検証' : '移行'}完了！`);
    
    if (dryRun) {
      console.log('');
      console.log('問題なければ --dry-run を外して再実行してください。');
    }
  } catch (error) {
    console.error('');
    console.error('❌ エラーが発生しました:');
    console.error(error);
    process.exit(1);
  }
}

main();
