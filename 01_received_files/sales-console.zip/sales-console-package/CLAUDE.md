# CLAUDE.md

このファイルは Claude Code がこのプロジェクトを実装する際のマスター指示書です。

## プロジェクト概要

**KOGAホールディングス海外飲食店 売上管理システム（Sales Console）**

タイ・インドネシアの飲食店3店舗の日次オペレーションを統合管理するWebアプリケーション。現場入力→本部リアルタイム把握→月次PL自動化を実現する。

**開発体制**: 比嘉俊一（KOGAホールディングス専務取締役・COO/CFO）が単独でClaude Codeと協働して実装。

## 重要な前提

以下の文書は事前に確定済み。実装中に矛盾を感じたら**必ず比嘉専務に確認**してから進めること。

| 文書 | バージョン | 場所 |
|---|---|---|
| 要件定義書 | v2.2 | `/docs/requirements_v2.2.md` |
| データモデル設計書 | v1.5 | `/docs/data_model_v1.5.md` |
| 画面設計書 | v1.0 | `/docs/screen_design_v1.0.md` |
| 実装計画書 | v1.0 | `/docs/IMPLEMENTATION_PLAN_v1.0.md` |
| UI参考artifact | 15画面分 | `/reference-artifacts/*.jsx` |

## 技術スタック

| 層 | 技術 |
|---|---|
| フロントエンド | Next.js 14 App Router + TypeScript |
| UI | Tailwind CSS + shadcn/ui |
| アイコン | lucide-react |
| チャート | recharts |
| バックエンド | Supabase (PostgreSQL + Auth + Storage) |
| デプロイ | Vercel (frontend) + Supabase (backend) |
| Excel処理 | SheetJS (xlsx) |
| 日付処理 | date-fns |

## ディレクトリ構造

```
app/
├── (auth)/              # 認証不要画面
│   ├── login/
│   ├── reset-password/
│   └── change-password/
├── (app)/               # 認証必須画面
│   ├── layout.tsx       # 共通レイアウト（ヘッダー・ナビ）
│   ├── dashboard/
│   ├── input/           # 日次入力
│   ├── targets/
│   ├── data/
│   ├── masters/
│   ├── admin/
│   └── profile/
└── api/
    ├── reports/
    ├── exports/
    └── imports/
```

## コーディング規約

### TypeScript

- `any` の使用禁止。`unknown` を使うか、適切に型定義する
- DBから取得する値は `Database['public']['Tables']['...']['Row']` 型を使用
- 関数の引数・戻り値は明示的に型注釈
- 列挙型は文字列リテラル型で定義（`type Role = 'executive' | 'staff' | ...`）

### React

- Server Components をデフォルト、必要な場合のみ `'use client'`
- フォームは Server Actions を優先
- `useState` の最小化、URL state（searchParams）を活用
- コンポーネントは `components/features/` または `components/shared/` に配置

### Tailwind / UI

- 参考artifact（`/reference-artifacts/`）の見た目を**忠実に再現**
- フォント: Bricolage Grotesque（見出し）+ Manrope（本文）+ JetBrains Mono（数字）+ Noto Sans JP
- カラー: 白背景 + slate-900テキスト + 達成度色分け（緑・黒・朱）
- shadcn/ui のコンポーネントを基盤に、必要に応じて拡張

### 達成率の色分け（システム全体共通ルール）

```typescript
// utils/achievement.ts
export function getAchievementColor(pct: number): 'success' | 'neutral' | 'warning' {
  if (pct >= 100) return 'success';   // 緑（emerald）
  if (pct >= 95) return 'neutral';    // 黒（slate-900）
  return 'warning';                   // 朱色（rose）
}
```

このルールは**すべての達成率表示で必ず適用**すること（要件定義書 v2.1 6.0節）。

## 重要な実装ルール

### 1. 月末レート方式（為替）

`exchange_rates` は通貨ペアごとに1値のみ保持。**当月の全データは現在のレートで換算**される。レート更新時は過去データも遡って再計算される（要件定義書 v2.2 6.4節）。

```typescript
// JPY換算
const jpyAmount = originalAmount * exchangeRate.rate;
// effective_date は計算に使用しない（メタ情報のみ）
```

### 2. Excel取込は常に上書き方式

UPSERT を使用。マッチする既存レコードは上書き、なければ追加。

```sql
INSERT INTO daily_sales (store_id, business_date, day_period, gross_sales, ...)
VALUES (...)
ON CONFLICT (store_id, business_date, day_period)
DO UPDATE SET
  gross_sales = EXCLUDED.gross_sales,
  ...
  updated_at = NOW();
```

UNIQUE制約（マッチング条件）：
- `daily_sales`: (store_id, business_date, day_period)
- `daily_purchases`: (store_id, business_date, supplier_id)
- `daily_expenses`: (store_id, business_date, expense_account_id)
- `daily_targets`: (store_id, target_date)

### 3. 削除ではなく無効化（ソフト削除）

退職者・廃止店舗・廃止科目等は**削除せず `is_active = FALSE` で対応**。過去データの整合性を保護。

### 4. 売上の税計算

```typescript
// タイ：tax_base='net_sales'（税抜売上のみに課税）
// インドネシア：tax_base='net_plus_service'（税抜+サービス料に課税）

function calculateTaxAndService(grossSales: number, country: Country, store: Store) {
  const serviceFee = grossSales * store.service_fee_rate / (1 + store.service_fee_rate + country.tax_rate);
  
  if (country.tax_base === 'net_sales') {
    const netSales = grossSales / (1 + store.service_fee_rate + country.tax_rate) * (1 + store.service_fee_rate);
    const taxAmount = netSales * country.tax_rate;
    return { netSales, serviceFee, taxAmount };
  } else {
    // net_plus_service
    const netSales = grossSales / (1 + (1 + store.service_fee_rate) * country.tax_rate);
    const taxAmount = (netSales + serviceFee) * country.tax_rate;
    return { netSales, serviceFee, taxAmount };
  }
}
```

実装前に**必ず比嘉専務に税計算式を確認**すること（実例で検証）。

### 5. RLS（Row Level Security）

すべてのDBアクセスはSupabaseクライアント経由で実行され、RLSが自動適用される。`002_rls_policies.sql` を参照。

ヘルパー関数：
- `auth.user_role()` - ロール取得
- `auth.user_country()` - 所属国
- `auth.can_access_store(store_id)` - 店舗アクセス可否
- `auth.is_executive()` - 経営層判定

## Phase別の実装手順

### Phase A: 基盤構築（最初）

1. Supabase プロジェクト作成（Region: Tokyo）
2. SQL Editor で `001_initial_schema.sql` → `002_rls_policies.sql` → `003_seed_data.sql` 順実行
3. Auth設定：Email有効化、TOTP有効化
4. Next.js プロジェクト初期化
5. `lib/supabase/client.ts`, `lib/supabase/server.ts`, `middleware.ts` 実装
6. ログイン画面実装（参考: `login_screen.jsx`）
7. (app) レイアウト + ヘッダー + ナビ実装
8. 簡易ダッシュボード実装（後でフル機能化）

### Phase B以降

実装計画書 v1.0 を参照。各フェーズで参考artifactを忠実に再現。

## 確認が必要な事項

実装中、以下の事項に遭遇したら**必ず比嘉専務に確認**：

- [ ] 店舗の正式名称（「あお季タイ」「AOKI ロバタ」「博多天神ジャカルタ」）
- [ ] 各店舗の仕入先完全リスト
- [ ] 各店舗の販管費科目完全リスト
- [ ] 初期ユーザーのメールアドレス・ロール
- [ ] Slack Webhook URL
- [ ] 期首棚卸の初期値
- [ ] データ移行範囲（過去何ヶ月）
- [ ] 税計算式の検算用サンプル

## トーンと進め方

- **結論先出し、根拠は後**：比嘉専務の好み
- **お世辞・忖度なし**：率直な指摘・提案を歓迎
- **不確実な情報は明示**：【憶測】【要確認】タグを使用
- **段階的に進める**：1つの機能を完成させてから次へ
- **Git commit は機能単位**：「日次入力画面の売上セクション実装」等

## デプロイ

### Vercel

```bash
# 本番デプロイ
git push origin main  # 自動デプロイ
```

環境変数：
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`（API Routes用、機微）
- `SLACK_WEBHOOK_URL`（system_settings に保存も可）

### Vercel Cron（日報配信用）

`vercel.json`:

```json
{
  "crons": [
    {
      "path": "/api/reports/daily",
      "schedule": "0 0 * * *"
    }
  ]
}
```

JSTで朝9時 = UTC 0:00。

## トラブルシューティング

### よくあるエラー

1. **RLSでデータが取れない** → `auth.uid()` が null。ログイン状態を確認
2. **UPSERTが効かない** → UNIQUE制約を確認（schema SQL参照）
3. **タイムゾーン問題** → 必ず `business_date DATE` で店舗ローカル日付を保存

## 参考実装：日次入力画面の構造

参考artifact `daily_input_screen_v3.jsx` を**忠実に再現**：

1. ヒーローカード：達成率を大きく表示（色分けルール厳守）
2. 5セクション：基本情報・売上・仕入・販管費・概算棚卸
3. 仕入：「一括チェックリスト方式」（カテゴリ別グループ、空欄=仕入なし）
4. Sticky保存バー：常にアクセス可能
5. リアルタイム計算：税抜・サービス料・税額の自動計算

## 連絡先

実装中に質問・課題があれば、まず比嘉専務に直接相談。Claude Code は提案するが、**重要な判断は必ず比嘉専務が下す**。
