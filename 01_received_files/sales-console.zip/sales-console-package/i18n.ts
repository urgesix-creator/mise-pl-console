/**
 * next-intl の getRequestConfig
 * Server Component / Server Action でロケールを解決
 *
 * このファイルは next-intl のエントリポイントとして
 * プロジェクトルートの i18n.ts に配置する
 */

import { getRequestConfig } from 'next-intl/server';
import { createClient } from '@/lib/supabase/server';
import { headers } from 'next/headers';
import { DEFAULT_LOCALE, detectLocaleFromHeader, isValidLocale, type Locale } from '@/lib/i18n/locales';

export default getRequestConfig(async () => {
  const locale = await resolveLocale();
  
  return {
    locale,
    messages: (await import(`./messages/${locale}.json`)).default,
    timeZone: 'Asia/Tokyo',
    now: new Date(),
  };
});

/**
 * ユーザーロケールの解決優先順位：
 * 1. ログイン済みユーザーの profiles.language
 * 2. Accept-Language ヘッダ
 * 3. デフォルト（ja）
 */
async function resolveLocale(): Promise<Locale> {
  try {
    // 1. ログイン済みユーザーの設定を確認
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    
    if (user) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('language')
        .eq('id', user.id)
        .single();
      
      if (profile && isValidLocale(profile.language)) {
        return profile.language;
      }
    }
  } catch {
    // エラーは無視（middleware等の文脈で auth が使えないケース）
  }
  
  // 2. Accept-Language ヘッダから推定
  try {
    const acceptLanguage = headers().get('accept-language');
    return detectLocaleFromHeader(acceptLanguage);
  } catch {
    return DEFAULT_LOCALE;
  }
}
