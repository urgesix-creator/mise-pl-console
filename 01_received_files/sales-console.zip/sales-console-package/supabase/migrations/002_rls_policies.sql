-- ====================================================================
-- Row Level Security Policies v1.0
-- 5ロールに対するアクセス制御
-- ====================================================================

-- ====================================================================
-- HELPER FUNCTIONS
-- ====================================================================

-- 現在のユーザーのロール取得
CREATE OR REPLACE FUNCTION auth.user_role()
RETURNS TEXT AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid() AND is_active = TRUE;
$$ LANGUAGE SQL STABLE SECURITY DEFINER;

-- 現在のユーザーの所属国取得
CREATE OR REPLACE FUNCTION auth.user_country()
RETURNS TEXT AS $$
  SELECT country_id FROM public.profiles WHERE id = auth.uid() AND is_active = TRUE;
$$ LANGUAGE SQL STABLE SECURITY DEFINER;

-- 現在のユーザーが指定店舗にアクセス可能か
CREATE OR REPLACE FUNCTION auth.can_access_store(p_store_id UUID)
RETURNS BOOLEAN AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
      AND p.is_active = TRUE
      AND (
        -- 経営層・経理は全店アクセス
        p.role IN ('executive', 'accounting')
        -- 各国代表は担当国の店舗
        OR (p.role = 'country_rep' AND EXISTS (
          SELECT 1 FROM public.stores s
          WHERE s.id = p_store_id AND s.country_id = p.country_id
        ))
        -- 店長・現場社員は割当店舗のみ
        OR EXISTS (
          SELECT 1 FROM public.user_store_assignments usa
          WHERE usa.user_id = p.id AND usa.store_id = p_store_id
        )
      )
  );
$$ LANGUAGE SQL STABLE SECURITY DEFINER;

-- 現在のユーザーが書き込み権限を持つか
CREATE OR REPLACE FUNCTION auth.can_write()
RETURNS BOOLEAN AS $$
  SELECT (auth.user_role()) IN ('executive', 'country_rep', 'store_manager', 'staff');
$$ LANGUAGE SQL STABLE SECURITY DEFINER;

-- 現在のユーザーが管理者権限（経営層）か
CREATE OR REPLACE FUNCTION auth.is_executive()
RETURNS BOOLEAN AS $$
  SELECT (auth.user_role()) = 'executive';
$$ LANGUAGE SQL STABLE SECURITY DEFINER;

-- ====================================================================
-- ENABLE RLS ON ALL TABLES
-- ====================================================================
ALTER TABLE countries ENABLE ROW LEVEL SECURITY;
ALTER TABLE currencies ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_store_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE exchange_rates ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE expense_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_targets ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_estimates ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- ====================================================================
-- countries / currencies (read-only for all authenticated, write for executive)
-- ====================================================================
CREATE POLICY "countries_read_authenticated" ON countries
  FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY "countries_write_executive" ON countries
  FOR ALL TO authenticated USING (auth.is_executive()) WITH CHECK (auth.is_executive());

CREATE POLICY "currencies_read_authenticated" ON currencies
  FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY "currencies_write_executive" ON currencies
  FOR ALL TO authenticated USING (auth.is_executive()) WITH CHECK (auth.is_executive());

-- ====================================================================
-- profiles
-- ====================================================================
-- 自分のプロファイルは閲覧可能
CREATE POLICY "profiles_read_self" ON profiles
  FOR SELECT TO authenticated USING (id = auth.uid());

-- 経営層・経理は全プロファイル閲覧可能
CREATE POLICY "profiles_read_admin" ON profiles
  FOR SELECT TO authenticated USING (auth.user_role() IN ('executive', 'accounting'));

-- 経営層は全プロファイル編集可能
CREATE POLICY "profiles_write_executive" ON profiles
  FOR ALL TO authenticated USING (auth.is_executive()) WITH CHECK (auth.is_executive());

-- 自分のプロファイル（display_name のみ）は更新可能
CREATE POLICY "profiles_update_self" ON profiles
  FOR UPDATE TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());

-- ====================================================================
-- stores
-- ====================================================================
-- 認証済みユーザーは自分のアクセス可能な店舗を閲覧
CREATE POLICY "stores_read_accessible" ON stores
  FOR SELECT TO authenticated USING (auth.can_access_store(id));

-- 経営層は全店舗の書き込み可能
CREATE POLICY "stores_write_executive" ON stores
  FOR ALL TO authenticated USING (auth.is_executive()) WITH CHECK (auth.is_executive());

-- ====================================================================
-- user_store_assignments
-- ====================================================================
CREATE POLICY "user_store_read_self_or_admin" ON user_store_assignments
  FOR SELECT TO authenticated USING (
    user_id = auth.uid() OR auth.user_role() IN ('executive', 'accounting')
  );

CREATE POLICY "user_store_write_executive" ON user_store_assignments
  FOR ALL TO authenticated USING (auth.is_executive()) WITH CHECK (auth.is_executive());

-- ====================================================================
-- exchange_rates
-- ====================================================================
CREATE POLICY "exchange_rates_read_authenticated" ON exchange_rates
  FOR SELECT TO authenticated USING (TRUE);

CREATE POLICY "exchange_rates_write_executive" ON exchange_rates
  FOR ALL TO authenticated USING (auth.is_executive()) WITH CHECK (auth.is_executive());

-- ====================================================================
-- purchase_categories（店舗別マスタ）
-- ====================================================================
CREATE POLICY "purchase_categories_read_accessible" ON purchase_categories
  FOR SELECT TO authenticated USING (auth.can_access_store(store_id));

-- 経営層・各国代表・店長は書き込み可能
CREATE POLICY "purchase_categories_write" ON purchase_categories
  FOR ALL TO authenticated USING (
    auth.user_role() IN ('executive', 'country_rep', 'store_manager')
    AND auth.can_access_store(store_id)
  ) WITH CHECK (
    auth.user_role() IN ('executive', 'country_rep', 'store_manager')
    AND auth.can_access_store(store_id)
  );

-- ====================================================================
-- suppliers
-- ====================================================================
CREATE POLICY "suppliers_read_accessible" ON suppliers
  FOR SELECT TO authenticated USING (auth.can_access_store(store_id));

CREATE POLICY "suppliers_write" ON suppliers
  FOR ALL TO authenticated USING (
    auth.user_role() IN ('executive', 'country_rep', 'store_manager')
    AND auth.can_access_store(store_id)
  ) WITH CHECK (
    auth.user_role() IN ('executive', 'country_rep', 'store_manager')
    AND auth.can_access_store(store_id)
  );

-- ====================================================================
-- expense_accounts
-- ====================================================================
CREATE POLICY "expense_accounts_read_accessible" ON expense_accounts
  FOR SELECT TO authenticated USING (auth.can_access_store(store_id));

CREATE POLICY "expense_accounts_write" ON expense_accounts
  FOR ALL TO authenticated USING (
    auth.user_role() IN ('executive', 'country_rep', 'store_manager')
    AND auth.can_access_store(store_id)
  ) WITH CHECK (
    auth.user_role() IN ('executive', 'country_rep', 'store_manager')
    AND auth.can_access_store(store_id)
  );

-- ====================================================================
-- daily_sales（最重要：日次入力データ）
-- ====================================================================
CREATE POLICY "daily_sales_read_accessible" ON daily_sales
  FOR SELECT TO authenticated USING (auth.can_access_store(store_id));

-- 書き込み：経営層・各国代表・店長・現場社員（全員）
CREATE POLICY "daily_sales_write" ON daily_sales
  FOR ALL TO authenticated USING (
    auth.can_write() AND auth.can_access_store(store_id)
  ) WITH CHECK (
    auth.can_write() AND auth.can_access_store(store_id)
  );

-- ====================================================================
-- daily_purchases
-- ====================================================================
CREATE POLICY "daily_purchases_read_accessible" ON daily_purchases
  FOR SELECT TO authenticated USING (auth.can_access_store(store_id));

CREATE POLICY "daily_purchases_write" ON daily_purchases
  FOR ALL TO authenticated USING (
    auth.can_write() AND auth.can_access_store(store_id)
  ) WITH CHECK (
    auth.can_write() AND auth.can_access_store(store_id)
  );

-- ====================================================================
-- daily_expenses
-- ====================================================================
CREATE POLICY "daily_expenses_read_accessible" ON daily_expenses
  FOR SELECT TO authenticated USING (auth.can_access_store(store_id));

CREATE POLICY "daily_expenses_write" ON daily_expenses
  FOR ALL TO authenticated USING (
    auth.can_write() AND auth.can_access_store(store_id)
  ) WITH CHECK (
    auth.can_write() AND auth.can_access_store(store_id)
  );

-- ====================================================================
-- daily_targets
-- ====================================================================
CREATE POLICY "daily_targets_read_accessible" ON daily_targets
  FOR SELECT TO authenticated USING (auth.can_access_store(store_id));

-- 目標は店長以上が変更可能
CREATE POLICY "daily_targets_write" ON daily_targets
  FOR ALL TO authenticated USING (
    auth.user_role() IN ('executive', 'country_rep', 'store_manager')
    AND auth.can_access_store(store_id)
  ) WITH CHECK (
    auth.user_role() IN ('executive', 'country_rep', 'store_manager')
    AND auth.can_access_store(store_id)
  );

-- ====================================================================
-- inventory_estimates
-- ====================================================================
CREATE POLICY "inventory_estimates_read_accessible" ON inventory_estimates
  FOR SELECT TO authenticated USING (auth.can_access_store(store_id));

CREATE POLICY "inventory_estimates_write" ON inventory_estimates
  FOR ALL TO authenticated USING (
    auth.can_write() AND auth.can_access_store(store_id)
  ) WITH CHECK (
    auth.can_write() AND auth.can_access_store(store_id)
  );

-- ====================================================================
-- system_settings（経営層のみ）
-- ====================================================================
CREATE POLICY "system_settings_read_authenticated" ON system_settings
  FOR SELECT TO authenticated USING (TRUE);

CREATE POLICY "system_settings_write_executive" ON system_settings
  FOR ALL TO authenticated USING (auth.is_executive()) WITH CHECK (auth.is_executive());

-- ====================================================================
-- 完了通知
-- ====================================================================
DO $$
BEGIN
  RAISE NOTICE '✅ RLS policies applied successfully';
  RAISE NOTICE '   - 5 helper functions created';
  RAISE NOTICE '   - 15 tables secured with RLS';
  RAISE NOTICE '   - Policies enforce role-based access:';
  RAISE NOTICE '     • executive: full access';
  RAISE NOTICE '     • country_rep: country-specific stores';
  RAISE NOTICE '     • store_manager: assigned store';
  RAISE NOTICE '     • staff: assigned store (input only)';
  RAISE NOTICE '     • accounting: read-all, no write';
  RAISE NOTICE 'Next: Run 003_seed_data.sql';
END $$;
