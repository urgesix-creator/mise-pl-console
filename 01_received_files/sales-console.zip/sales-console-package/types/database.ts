/**
 * Supabase Database Types
 * このファイルは手動で定義されたものです。
 * 本番ではSupabase CLIで自動生成することを推奨：
 *   npx supabase gen types typescript --project-id YOUR_PROJECT_ID > types/database.ts
 */

export type Database = {
  public: {
    Tables: {
      countries: {
        Row: {
          id: string;
          name: string;
          code: string;
          flag: string | null;
          tax_rate: number;
          tax_base: 'net_sales' | 'net_plus_service';
          tax_label: string;
          display_order: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['countries']['Row'], 'created_at' | 'updated_at'> & {
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['countries']['Insert']>;
      };
      currencies: {
        Row: {
          id: string;
          code: string;
          symbol: string;
          name: string;
          display_order: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['currencies']['Row'], 'created_at' | 'updated_at'> & {
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['currencies']['Insert']>;
      };
      profiles: {
        Row: {
          id: string;
          display_name: string;
          email: string;
          role: 'executive' | 'country_rep' | 'store_manager' | 'staff' | 'accounting';
          country_id: string | null;
          is_active: boolean;
          has_2fa: boolean;
          invited_at: string | null;
          accepted_at: string | null;
          last_login_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['profiles']['Row'], 'created_at' | 'updated_at'> & {
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['profiles']['Insert']>;
      };
      stores: {
        Row: {
          id: string;
          name: string;
          country_id: string;
          currency_id: string;
          timezone: string;
          service_fee_rate: number;
          is_lunch_dinner_split: boolean;
          is_weather_enabled: boolean;
          is_event_enabled: boolean;
          is_active: boolean;
          established_date: string | null;
          display_order: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['stores']['Row'], 'id' | 'created_at' | 'updated_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['stores']['Insert']>;
      };
      user_store_assignments: {
        Row: {
          id: string;
          user_id: string;
          store_id: string;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['user_store_assignments']['Row'], 'id' | 'created_at'> & {
          id?: string;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['user_store_assignments']['Insert']>;
      };
      exchange_rates: {
        Row: {
          id: string;
          from_currency_id: string;
          to_currency_id: string;
          rate: number;
          effective_date: string;
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['exchange_rates']['Row'], 'id' | 'created_at' | 'updated_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['exchange_rates']['Insert']>;
      };
      purchase_categories: {
        Row: {
          id: string;
          store_id: string;
          name: string;
          display_order: number;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['purchase_categories']['Row'], 'id' | 'created_at' | 'updated_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['purchase_categories']['Insert']>;
      };
      suppliers: {
        Row: {
          id: string;
          store_id: string;
          category_id: string;
          name: string;
          display_order: number;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['suppliers']['Row'], 'id' | 'created_at' | 'updated_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['suppliers']['Insert']>;
      };
      expense_accounts: {
        Row: {
          id: string;
          store_id: string;
          name: string;
          level1: ExpenseLevel1;
          display_order: number;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['expense_accounts']['Row'], 'id' | 'created_at' | 'updated_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['expense_accounts']['Insert']>;
      };
      daily_sales: {
        Row: {
          id: string;
          store_id: string;
          business_date: string;
          day_period: 'all' | 'lunch' | 'dinner';
          gross_sales: number;
          net_sales: number;
          service_fee: number;
          tax_amount: number;
          customer_count: number;
          weather: string | null;
          event_note: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['daily_sales']['Row'], 'id' | 'created_at' | 'updated_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['daily_sales']['Insert']>;
      };
      daily_purchases: {
        Row: {
          id: string;
          store_id: string;
          supplier_id: string;
          business_date: string;
          amount: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['daily_purchases']['Row'], 'id' | 'created_at' | 'updated_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['daily_purchases']['Insert']>;
      };
      daily_expenses: {
        Row: {
          id: string;
          store_id: string;
          expense_account_id: string;
          business_date: string;
          amount: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['daily_expenses']['Row'], 'id' | 'created_at' | 'updated_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['daily_expenses']['Insert']>;
      };
      daily_targets: {
        Row: {
          id: string;
          store_id: string;
          target_date: string;
          target_sales: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['daily_targets']['Row'], 'id' | 'created_at' | 'updated_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['daily_targets']['Insert']>;
      };
      inventory_estimates: {
        Row: {
          store_id: string;
          amount: number;
          estimated_date: string;
          notes: string | null;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['inventory_estimates']['Row'], 'updated_at'> & {
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['inventory_estimates']['Insert']>;
      };
      system_settings: {
        Row: {
          key: string;
          value: unknown; // JSONB
          description: string | null;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['system_settings']['Row'], 'updated_at'> & {
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['system_settings']['Insert']>;
      };
    };
    Views: {
      v_daily_sales_with_target: {
        Row: {
          sale_id: string;
          store_id: string;
          business_date: string;
          day_period: 'all' | 'lunch' | 'dinner';
          gross_sales: number;
          net_sales: number;
          customer_count: number;
          avg_per_customer: number;
          target_sales: number;
          achievement_pct: number | null;
          store_name: string;
          currency_id: string;
        };
      };
    };
    Functions: Record<string, never>;
    Enums: Record<string, never>;
  };
};

// ====================================================================
// Convenience Type Aliases
// ====================================================================

export type Country = Database['public']['Tables']['countries']['Row'];
export type Currency = Database['public']['Tables']['currencies']['Row'];
export type Profile = Database['public']['Tables']['profiles']['Row'];
export type Store = Database['public']['Tables']['stores']['Row'];
export type UserStoreAssignment = Database['public']['Tables']['user_store_assignments']['Row'];
export type ExchangeRate = Database['public']['Tables']['exchange_rates']['Row'];
export type PurchaseCategory = Database['public']['Tables']['purchase_categories']['Row'];
export type Supplier = Database['public']['Tables']['suppliers']['Row'];
export type ExpenseAccount = Database['public']['Tables']['expense_accounts']['Row'];
export type DailySale = Database['public']['Tables']['daily_sales']['Row'];
export type DailyPurchase = Database['public']['Tables']['daily_purchases']['Row'];
export type DailyExpense = Database['public']['Tables']['daily_expenses']['Row'];
export type DailyTarget = Database['public']['Tables']['daily_targets']['Row'];
export type InventoryEstimate = Database['public']['Tables']['inventory_estimates']['Row'];
export type SystemSetting = Database['public']['Tables']['system_settings']['Row'];

// ====================================================================
// Enum-like Types
// ====================================================================

export type UserRole = 'executive' | 'country_rep' | 'store_manager' | 'staff' | 'accounting';
export type DayPeriod = 'all' | 'lunch' | 'dinner';
export type TaxBase = 'net_sales' | 'net_plus_service';

export type ExpenseLevel1 =
  | '人件費'
  | '賃料'
  | '光熱費'
  | '広告宣伝費'
  | '減価償却費'
  | '支払手数料'
  | '消耗品費'
  | 'その他販管費';

export const EXPENSE_LEVEL1_LIST: ExpenseLevel1[] = [
  '人件費',
  '賃料',
  '光熱費',
  '広告宣伝費',
  '減価償却費',
  '支払手数料',
  '消耗品費',
  'その他販管費',
];

// ====================================================================
// Role Configuration
// ====================================================================

export const ROLE_LABELS: Record<UserRole, { label: string; sub: string; description: string }> = {
  executive: {
    label: '経営層',
    sub: 'Executive',
    description: '全店全機能アクセス、最高権限',
  },
  country_rep: {
    label: '各国代表',
    sub: 'Country Rep',
    description: '担当国の全店舗を管理',
  },
  store_manager: {
    label: '店舗店長',
    sub: 'Store Manager',
    description: '担当店舗の入力・管理',
  },
  staff: {
    label: '現場社員',
    sub: 'Staff',
    description: '担当店舗の入力のみ',
  },
  accounting: {
    label: '経理・税理士',
    sub: 'Accounting',
    description: '全店読取・出力（編集不可）',
  },
};
